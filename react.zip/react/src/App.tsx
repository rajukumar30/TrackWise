import { Routes, Route, Link } from 'react-router-dom'
// import { AuthProvider, useAuth } from './context/AuthContext'
import NavBar from './components/NavBar'
// import Login from './pages/Login'
import Dashboard from './pages/Dashboard'
import Assets from './pages/Assets'
import Employees from './pages/Employees'
import CheckInOut from './pages/CheckInOut'
import Maintenance from './pages/Maintenance'
import Reports from './pages/Reports'
import Warranty from './pages/Warranty'
import Notifications from './pages/Notifications'
import Admin from './pages/Admin'
import IoT from './pages/IoT'

// Protected route wrapper (disabled for now; keep for future auth)
// function Protected({ children }: { children: JSX.Element }) {
//   const { token } = useAuth()
//   if (!token) return <Navigate to="/login" replace />
//   return children
// }

export default function App() {
  return (
    <>
      <NavBar />
      <div className="container">
        <Routes>
          {/* <Route path="/login" element={<Login />} /> */}
          <Route path="/" element={<Dashboard />} />
          <Route path="/assets" element={<Assets />} />
          <Route path="/employees" element={<Employees />} />
          <Route path="/check" element={<CheckInOut />} />
          <Route path="/maintenance" element={<Maintenance />} />
          <Route path="/reports" element={<Reports />} />
          <Route path="/warranty" element={<Warranty />} />
          <Route path="/notifications" element={<Notifications />} />
          <Route path="/admin" element={<Admin />} />
          <Route path="/iot" element={<IoT />} />
          <Route
            path="*"
            element={
              <div className="container">
                <h3>Not Found</h3>
                <Link to="/">Go Home</Link>
              </div>
            }
          />
        </Routes>
      </div>
    </>
  )
}
