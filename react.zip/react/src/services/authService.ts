import { request } from './api'
export async function login(email:string, password:string): Promise<string> {
  // Backend currently permits all /api/** without auth; simulate token for UI state
  const fakeToken = btoa(`${email}:${Date.now()}`)
  return fakeToken
}
