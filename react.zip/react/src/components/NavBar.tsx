import { Link } from 'react-router-dom'
export default function NavBar(){
  return <nav>
    <b><Link to="/">TrackWise</Link></b>
    <Link to="/">Dashboard</Link><Link to="/assets">Assets</Link><Link to="/employees">Employees</Link>
    <Link to="/check">Check In/Out</Link><Link to="/maintenance">Maintenance</Link><Link to="/reports">Reports</Link>
    <Link to="/warranty">Warranty</Link><Link to="/notifications">Notifications</Link><Link to="/iot">IoT</Link><Link to="/admin">Admin</Link>
    <span style={{marginLeft:'auto'}}>{/* Auth controls removed for now */}</span>
  </nav>
}
