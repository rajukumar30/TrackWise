# TrackWise Frontend (Functional)
Run:
```
npm i
echo "VITE_API_BASE_URL=http://localhost:8080" > .env
npm run dev
```
Adjust endpoints in `src/services/*` if your backend differs.
